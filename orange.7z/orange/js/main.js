$(function () {

  $('.header__btn-dark').on("click", function (event) {
    $('body, header, main').removeClass('active');
  });

 

  $('.header__btn-light').on("click", function (event) {
    $('body, header, main').addClass('active');
  });



  $('.header__lang').on("click", function (event) {
    $('.header__lang-all').toggleClass('header__lang-all-active');
  });



  $('.header__catalog, .header__burg-catalog').on("click", function (event) {
    $('.header__menu').toggleClass('header__menu-active');
  });



  $('.header__user').on("click", function (event) {
    $('.header__user-wrap').toggleClass('header__user-wrap-active');
  });



  $('.header__cart').on("click", function (event) {
    $('.header__cart-wrap').toggleClass('header__cart-wrap-active');
  });



  $('.header__burger-btn, .header__menu-btn-close').click(function (event) {
    $('.header__burger-menu').toggleClass('header__burger-menu-active');
    $('body').toggleClass('noscroll');
  });




  $(".footer__menu-col").on("click", function (t) {
    $(this).find('.footer__menu-svg').toggleClass("footer__menu-svg-active");
    $(this).parents().children('.footer__list').slideToggle(300);
  });



  $('.counter__plus').on("click", function (event) {
    $(this).prev().val(+$(this).prev().val() + 1);
  });
  $('.counter__minus').on("click", function (event) {
    if ($(this).next().val() > 0) $(this).next().val(+$(this).next().val() - 1);
  });





  var $status = $('.order__paging-info');
  var $slickElement = $('.order__slider');

  $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
    // no dots -> no slides
    if (!slick.$dots) {
      return;
    }

    //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
    var i = (currentSlide ? currentSlide : 0) + 1;
    // use dots to get some count information
    $status.text(i + '/' + (slick.$dots[0].children.length));
  });

  $slickElement.slick({
    arrows: true,
    dots: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 4,

    prevArrow: '<button type ="button" class ="slider__prev"><svg width="12" height="22" viewBox="0 0 12 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 1L2.41421 9.58579C1.63316 10.3668 1.63316 11.6332 2.41421 12.4142L11 21"stroke="#7981AD"stroke-width="2"/></svg></button>',
    nextArrow: '<button type ="button" class ="slider__next"><svg width="12" height="22" viewBox="0 0 12 22" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d = "M1 1L9.58579 9.58579C10.3668 10.3668 10.3668 11.6332 9.58579 12.4142L1 21"stroke = "#7981AD"stroke-width = "2" / ></svg></button>',
    responsive: [{

      breakpoint: 1200,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 800,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 400,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });



  var $status = $('.main__slider-paging-info');
  var $slickElement = $('.main__slider');

  $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
    // no dots -> no slides
    if (!slick.$dots) {
      return;
    }

    //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
    var i = (currentSlide ? currentSlide : 0) + 1;
    // use dots to get some count information
    $status.html('<span class="pag-active">' + i + '</span>' + ' &nbsp;&nbsp;/&nbsp;&nbsp; ' + (slick
      .$dots[0].children.length));
  });



  $slickElement.slick({
    arrows: true,
    dots: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    prevArrow: '<button type ="button" class ="prod__prev"><svg width="7" height="10" viewBox="0 0 7 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.03033 0.46967C6.32322 0.762563 6.32322 1.23744 6.03033 1.53033L2.56066 5L6.03033 8.46967C6.32322 8.76256 6.32322 9.23744 6.03033 9.53033C5.73744 9.82322 5.26256 9.82322 4.96967 9.53033L0.96967 5.53033C0.676777 5.23744 0.676777 4.76256 0.96967 4.46967L4.96967 0.46967C5.26256 0.176777 5.73744 0.176777 6.03033 0.46967Z" fill="#7F7F7F"/></svg></button>',
    nextArrow: '<button type ="button" class ="prod__next"><svg width="7" height="10" viewBox="0 0 7 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.96967 0.46967C1.26256 0.176777 1.73744 0.176777 2.03033 0.46967L6.03033 4.46967C6.32322 4.76256 6.32322 5.23744 6.03033 5.53033L2.03033 9.53033C1.73744 9.82322 1.26256 9.82322 0.96967 9.53033C0.676777 9.23744 0.676777 8.76256 0.96967 8.46967L4.43934 5L0.96967 1.53033C0.676777 1.23744 0.676777 0.762563 0.96967 0.46967Z" fill="#7F7F7F"/></svg></button>',

  });



  $('.collaboration__slider').slick({
    arrows: true,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 6,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 1200,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 992,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 600,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 400,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }]
  });


  $('.new-store__slider').slick({
    arrows: true,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 5,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 1400,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 1100,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 992,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 750,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 450,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });



  $('.blog__slider').slick({
    arrows: true,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 3,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 992,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 800,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 550,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });



  
  $('.services__wrapper-slider').slick({
    arrows:false,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 3,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 600,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 450,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });


  $('.special__inner').slick({
    arrows: true,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 3,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 1200,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 992,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 800,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 2,
        slidesToScroll: 1
      }
    }, {
      breakpoint: 550,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });

 
  $(window).on('load resize', function() {
    if ($(window).width() < 450) {
      $('.product__wrapper:not(.slick-initialized)').slick({
        arrows: false,
        dots: true,
        infinite: true,
        autoplaySpeed: 2000,
        slidesToShow: 1
      });
    } else {
      $(".product__wrapper.slick-initialized").slick("unslick");
    }
  });



/*  
 
  $('.product__cart-popup').magnificPopup({
    type: 'inline',
    removalDelay: 350,
    mainClass: 'mfp-fade'
  });

  $('.card__slider').magnificPopup({
    items: {
      src: 'images/card/photo.png'
    },
    type: 'image',
    gallery: {
      enabled: true
    },
  });



  $('.').slick({
    arrows: false,
    dots: false,
    infinite: true,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
    slidesToShow: 3,
    prevArrow: '<button type ="button" class ="colab-prev"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.0303 8.53033C11.3232 8.23744 11.3232 7.76256 11.0303 7.46967C10.7374 7.17678 10.2626 7.17678 9.96967 7.46967L5.96967 11.4697C5.82322 11.6161 5.75 11.8081 5.75 12C5.75 12.1017 5.77024 12.1987 5.80691 12.2871C5.84351 12.3755 5.89776 12.4584 5.96967 12.5303L9.96967 16.5303C10.2626 16.8232 10.7374 16.8232 11.0303 16.5303C11.3232 16.2374 11.3232 15.7626 11.0303 15.4697L8.31066 12.75H18C18.4142 12.75 18.75 12.4142 18.75 12C18.75 11.5858 18.4142 11.25 18 11.25H8.31066L11.0303 8.53033Z" fill="#4B4B4B"/></svg></button>',
    nextArrow: '<button type ="button" class ="colab-next"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M13.4697 8.53033C13.1768 8.23744 13.1768 7.76256 13.4697 7.46967C13.7626 7.17678 14.2374 7.17678 14.5303 7.46967L18.5303 11.4697C18.8232 11.7626 18.8232 12.2374 18.5303 12.5303L14.5303 16.5303C14.2374 16.8232 13.7626 16.8232 13.4697 16.5303C13.1768 16.2374 13.1768 15.7626 13.4697 15.4697L16.1893 12.75H6.5C6.08579 12.75 5.75 12.4142 5.75 12C5.75 11.5858 6.08579 11.25 6.5 11.25H16.1893L13.4697 8.53033Z" fill="#4B4B4B"/></svg></button>',
    responsive: [{

      breakpoint: 400,
      settings: {
        arrows: false,
        dots: true,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }]
  });




   $('/').magnificPopup({
     type: 'inline',
     removalDelay: 350,
     mainClass: 'mfp-fade',
     callbacks: {
       open: function () {
         $('/').slick({
           arrows: true,
           dots: false,
           slidesToScroll: 1,
           autoplaySpeed: 2000,
           slidesToShow: 1,
           prevArrow: '<button type ="button" class ="card-prev"><svg width="12" height="22" viewBox="0 0 12 22" fill="none"><path d="M11 1L2.41421 9.58579C1.63316 10.3668 1.63316 11.6332 2.41421 12.4142L11 21"stroke="#7981AD"stroke-width="2"/></svg></button>',
           nextArrow: '<button type ="button" class ="card-next"><svg width="12" height="22" viewBox="0 0 12 22" fill="none"> <path d = "M1 1L9.58579 9.58579C10.3668 10.3668 10.3668 11.6332 9.58579 12.4142L1 21"stroke = "#7981AD"stroke-width = "2" / ></svg></button>',

         });
       }
     }

   });?*/
});